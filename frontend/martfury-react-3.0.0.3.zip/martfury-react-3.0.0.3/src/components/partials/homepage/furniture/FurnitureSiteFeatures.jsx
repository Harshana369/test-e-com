import React from 'react';

const FurnitureTrendingProduct = () => (
    <div className="ps-home-trending-products ps-section--furniture">
        <div className="container">
            <div className="ps-section__header">
                <h3>BEST SELLER PRODUCTS</h3>
            </div>
            <div className="ps-section__content"></div>
        </div>
    </div>
);

export default FurnitureTrendingProduct;
