export const DEFAULT_PAGE_SIZE = 10;
export const STRAPI = 'STRAPI';
export const WORDPRESS = 'WORDPRESS';
export const APP_DATA_SET = STRAPI; // STRAPI| WORDPRESS
