export const productCollections = [
    {
        label: 'New arrivals',
        value: 'new-arrivals',
    },
    {
        label: 'Best sellers',
        value: 'best-seller',
    },
    {
        label: 'Most popular',
        value: 'most-popular',
    },
];
