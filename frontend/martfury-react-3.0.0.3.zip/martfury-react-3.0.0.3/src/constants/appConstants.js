export const APP_DEFAULT_PAGE_SIZE = 10;
