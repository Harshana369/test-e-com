'use strict';

/**
 * product-brand controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::product-brand.product-brand');
