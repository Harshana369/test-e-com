'use strict';

/**
 * product-brand service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::product-brand.product-brand');
