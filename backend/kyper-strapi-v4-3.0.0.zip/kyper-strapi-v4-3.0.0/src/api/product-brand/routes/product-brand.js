'use strict';

/**
 * product-brand router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::product-brand.product-brand');
