'use strict';

/**
 * product-collection controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::product-collection.product-collection');
