const nextSettings = {
    optimizeFonts: false,
    eslint: {
        ignoreDuringBuilds: true,
    },
};

module.exports = nextSettings;
