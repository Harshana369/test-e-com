## MARTFURY ADMIN TEMPLATE - REACT VERSION Version 3.0.0

Author: nouthemes
Homepage:
[Nouthemes](https://themeforest.net/user/nouthemes/portfolio)

Change logs:

Version 3.0.0
- Update: Update to ReactJS 18x
- Update NextJs to v14.x.x
- Update: Update all packages to latest version
- Update: Replace ReduxSaga by Redux Toolkit
- Change Page Structure to App Structure

